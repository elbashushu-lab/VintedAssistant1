package com.example.vintedassistant.ai

import android.util.Base64
import com.example.vintedassistant.data.Draft
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

private const val SYSTEM = """Sei un assistente che prepara annunci per la vendita di abbigliamento e oggetti usati su Vinted, in italiano.
REGOLE TASSATIVE:
- Usa SOLO informazioni che vedi nelle foto oppure che sono scritte nell'istruzione dell'utente.
- NON inventare marca, taglia, condizioni, materiale, misure o caratteristiche non verificabili. Marca e taglia vanno compilate solo se leggibili su etichette/cartellini o indicate dall'utente.
- Se un dato non è verificabile lascia la stringa vuota "" e inseriscilo in "da_verificare" con una breve nota.
- "condizioni": solo uno tra "Nuovo con cartellino", "Nuovo senza cartellino", "Ottime condizioni", "Buone condizioni", "Condizioni soddisfacenti", oppure "" se l'utente non lo indica e non è evidente (es. cartellino visibile).
- "prezzo": solo se l'utente lo indica, altrimenti "".
- Segnala difetti solo se visibili nelle foto o dichiarati dall'utente.
- Applica le indicazioni comuni dell'utente (tono, saluti, spedizione, sconti sui lotti, ecc.) alla descrizione.
- Titolo: massimo 60 caratteri, chiaro, con tipo di articolo, colore e (se verificati) marca/taglia. Descrizione: naturale, onesta, massimo 1500 caratteri.
Rispondi ESCLUSIVAMENTE con un oggetto JSON con queste chiavi:
{"titolo":"","descrizione":"","categoria":"","marca":"","taglia":"","condizioni":"","colore":"","materiale":"","prezzo":"","hashtag":[],"da_verificare":[]}"""

class AiClient(private val apiKey: String, private val model: String) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS).readTimeout(120, TimeUnit.SECONDS).build()

    suspend fun analyze(photos: List<File>, instruction: String, index: Int, photoPaths: List<String>): Draft =
        withContext(Dispatchers.IO) {
            val content = JSONArray()
            photos.forEach { f ->
                content.put(JSONObject().put("type", "image").put("source", JSONObject()
                    .put("type", "base64").put("media_type", "image/jpeg")
                    .put("data", Base64.encodeToString(f.readBytes(), Base64.NO_WRAP))))
            }
            content.put(JSONObject().put("type", "text").put("text",
                "ISTRUZIONE UNICA (valida per tutti gli articoli):\n" +
                    (instruction.ifBlank { "(nessuna)" }) +
                    "\n\nAnalizza SOLO le foto allegate, che mostrano l'articolo n. ${index + 1}. Rispondi solo con il JSON."))
            val body = JSONObject().put("model", model).put("max_tokens", 1500).put("system", SYSTEM)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
            val req = Request.Builder().url("https://api.anthropic.com/v1/messages")
                .header("x-api-key", apiKey).header("anthropic-version", "2023-06-01")
                .post(body.toString().toRequestBody("application/json".toMediaType())).build()
            http.newCall(req).execute().use { r ->
                val raw = r.body?.string().orEmpty()
                if (!r.isSuccessful) {
                    val msg = runCatching { JSONObject(raw).getJSONObject("error").getString("message") }.getOrDefault(raw.take(200))
                    error("Errore API ${r.code}: $msg")
                }
                val blocks = JSONObject(raw).getJSONArray("content")
                val text = (0 until blocks.length()).map { blocks.getJSONObject(it) }
                    .filter { it.optString("type") == "text" }.joinToString("") { it.getString("text") }
                val start = text.indexOf('{'); val end = text.lastIndexOf('}')
                require(start >= 0 && end > start) { "Risposta AI non valida" }
                toDraft(JSONObject(text.substring(start, end + 1)), photoPaths)
            }
        }

    private fun JSONObject.s(k: String) = optString(k, "").trim().takeIf { it != "null" }.orEmpty()
    private fun JSONObject.list(k: String): List<String> {
        val a = optJSONArray(k) ?: return emptyList()
        return (0 until a.length()).map { a.optString(it).trim() }.filter { it.isNotBlank() }
    }

    private fun toDraft(j: JSONObject, photos: List<String>) = Draft(
        photos = photos, title = j.s("titolo"), description = j.s("descrizione"),
        category = j.s("categoria"), brand = j.s("marca"), size = j.s("taglia"),
        condition = j.s("condizioni"), color = j.s("colore"), material = j.s("materiale"),
        price = j.s("prezzo"),
        hashtags = j.list("hashtag").joinToString(" ") { if (it.startsWith("#")) it else "#$it" },
        warnings = j.list("da_verificare"),
    )
}
