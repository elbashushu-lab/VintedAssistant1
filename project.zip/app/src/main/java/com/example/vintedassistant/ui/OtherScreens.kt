package com.example.vintedassistant.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.vintedassistant.MainViewModel
import com.example.vintedassistant.data.ItemEntity
import java.io.File
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedScreen(vm: MainViewModel, onBack: () -> Unit, onOpen: (ItemEntity) -> Unit) {
    val list by vm.saved.collectAsState()
    Scaffold(topBar = {
        TopAppBar(title = { Text("Schede salvate") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") } })
    }) { pad ->
        if (list.isEmpty()) Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { Text("Nessuna scheda salvata") }
        else LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(list, key = { it.id }) { e ->
                ElevatedCard(Modifier.fillMaxWidth().clickable { onOpen(e) }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        AsyncImage(File(e.photos.split("|").first()), null, Modifier.size(72.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
                        Column(Modifier.weight(1f)) {
                            Text(e.title.ifBlank { "(senza titolo)" }, style = MaterialTheme.typography.titleSmall, maxLines = 2)
                            Text(DateFormat.getDateInstance().format(Date(e.createdAt)), style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { vm.delete(e) }) { Icon(Icons.Default.Delete, "Elimina") }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    var key by remember { mutableStateOf(vm.settings.apiKey) }
    var model by remember { mutableStateOf(vm.settings.model) }
    Scaffold(topBar = {
        TopAppBar(title = { Text("Impostazioni") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") } })
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("L'analisi delle foto usa l'API Anthropic (Claude) con la tua chiave personale, salvata solo su questo telefono. Le foto vengono inviate all'API per l'analisi.",
                style = MaterialTheme.typography.bodyMedium)
            OutlinedTextField(key, { key = it }, label = { Text("Chiave API Anthropic") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(model, { model = it }, label = { Text("Modello") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(onClick = { vm.settings.apiKey = key; vm.settings.model = model; onBack() }, modifier = Modifier.fillMaxWidth()) { Text("Salva") }
        }
    }
}
