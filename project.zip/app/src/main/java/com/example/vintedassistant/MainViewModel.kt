package com.example.vintedassistant

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.vintedassistant.ai.AiClient
import com.example.vintedassistant.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).itemDao()
    val settings = Settings(app)

    var picked by mutableStateOf(List(3) { emptyList<Uri>() }); private set
    var instruction by mutableStateOf("")
    var drafts by mutableStateOf(emptyList<Draft>()); private set
    var generating by mutableStateOf(false); private set
    var message by mutableStateOf<String?>(null)
    var startTab by mutableIntStateOf(0)

    val saved = dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setPhotos(i: Int, uris: List<Uri>) {
        picked = picked.toMutableList().also { it[i] = uris.take(MAX_PHOTOS) }
    }

    fun generate(onDone: () -> Unit) {
        if (picked.any { it.isEmpty() }) { message = "Seleziona almeno una foto per ciascuno dei 3 articoli"; return }
        if (settings.apiKey.isBlank()) { message = "Inserisci la chiave API nelle Impostazioni"; return }
        viewModelScope.launch {
            generating = true
            try {
                // elimina foto di bozze precedenti non salvate
                drafts.filter { it.savedId == null }.flatMap { it.photos }.forEach { File(it).delete() }
                val ctx = getApplication<Application>()
                val client = AiClient(settings.apiKey, settings.model)
                val result = coroutineScope {
                    picked.mapIndexed { i, uris ->
                        async {
                            val files = withContext(Dispatchers.IO) { uris.map { PhotoStore.import(ctx, it) } }
                            val paths = files.map { it.absolutePath }
                            runCatching { client.analyze(files, instruction, i, paths) }
                                .getOrElse { Draft(photos = paths, error = it.message ?: "Errore sconosciuto") }
                        }
                    }.awaitAll()
                }
                drafts = result; startTab = 0
                onDone()
            } catch (e: Exception) {
                message = "Errore: ${e.message}"
            } finally { generating = false }
        }
    }

    fun regenerate(i: Int) {
        val d = drafts.getOrNull(i) ?: return
        viewModelScope.launch {
            generating = true
            try {
                val files = d.photos.map { File(it) }
                val n = AiClient(settings.apiKey, settings.model).analyze(files, instruction, i, d.photos)
                edit(i) { n.copy(savedId = it.savedId, createdAt = it.createdAt) }
            } catch (e: Exception) { message = "Errore: ${e.message}" } finally { generating = false }
        }
    }

    fun edit(i: Int, f: (Draft) -> Draft) {
        drafts = drafts.toMutableList().also { it[i] = f(it[i]) }
    }

    fun save(i: Int) = viewModelScope.launch { saveInternal(i); message = "Scheda salvata" }
    fun saveAll() = viewModelScope.launch { drafts.indices.forEach { saveInternal(it) }; message = "Schede salvate" }

    private suspend fun saveInternal(i: Int) {
        val d = drafts[i]
        if (d.savedId == null) { val id = dao.insert(d.toEntity()); edit(i) { it.copy(savedId = id) } }
        else dao.update(d.toEntity())
    }

    fun open(e: ItemEntity) { drafts = listOf(e.toDraft()); startTab = 0 }

    fun delete(e: ItemEntity) = viewModelScope.launch(Dispatchers.IO) {
        dao.delete(e.id)
        e.photos.split("|").forEach { File(it).delete() }
    }
}
