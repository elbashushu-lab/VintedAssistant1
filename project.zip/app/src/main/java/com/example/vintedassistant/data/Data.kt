package com.example.vintedassistant.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** Scheda articolo in memoria (modificabile nell'anteprima). */
data class Draft(
    val savedId: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val photos: List<String> = emptyList(),
    val title: String = "",
    val description: String = "",
    val category: String = "",
    val brand: String = "",
    val size: String = "",
    val condition: String = "",
    val color: String = "",
    val material: String = "",
    val price: String = "",
    val hashtags: String = "",
    val warnings: List<String> = emptyList(),
    val error: String? = null,
) {
    fun fullText() = buildString {
        appendLine(title); appendLine(); append(description)
        if (hashtags.isNotBlank()) { appendLine(); appendLine(); append(hashtags) }
    }
}

@Entity(tableName = "items")
data class ItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAt: Long,
    val title: String, val description: String, val category: String,
    val brand: String, val size: String, val condition: String,
    val color: String, val material: String, val price: String,
    val hashtags: String, val warnings: String, val photos: String,
)

fun Draft.toEntity() = ItemEntity(
    id = savedId ?: 0, createdAt = createdAt, title = title, description = description,
    category = category, brand = brand, size = size, condition = condition, color = color,
    material = material, price = price, hashtags = hashtags,
    warnings = warnings.joinToString("\n"), photos = photos.joinToString("|"),
)

fun ItemEntity.toDraft() = Draft(
    savedId = id, createdAt = createdAt, photos = photos.split("|").filter { it.isNotBlank() },
    title = title, description = description, category = category, brand = brand, size = size,
    condition = condition, color = color, material = material, price = price, hashtags = hashtags,
    warnings = warnings.split("\n").filter { it.isNotBlank() },
)

@Dao
interface ItemDao {
    @Query("SELECT * FROM items ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<ItemEntity>>
    @Insert suspend fun insert(item: ItemEntity): Long
    @Update suspend fun update(item: ItemEntity)
    @Query("DELETE FROM items WHERE id = :id") suspend fun delete(id: Long)
}

@Database(entities = [ItemEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun itemDao(): ItemDao
    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(c: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDatabase::class.java, "vinted.db")
                .build().also { inst = it }
        }
    }
}

class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    var apiKey: String
        get() = p.getString("key", "") ?: ""
        set(v) = p.edit().putString("key", v.trim()).apply()
    var model: String
        get() = p.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) = p.edit().putString("model", v.trim().ifBlank { DEFAULT_MODEL }).apply()
    companion object { const val DEFAULT_MODEL = "claude-sonnet-5-5" }
}
