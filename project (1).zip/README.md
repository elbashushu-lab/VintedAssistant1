# Vinted Assistant

Kotlin + Jetpack Compose. L'APK viene compilato online da GitHub Actions (nessun PC necessario).

Vedi la guida passo-passo nella chat: crea repository -> carica project.zip -> crea build-apk.yml -> scarica l'APK dalle Release.
Dopo la prima installazione, inserisci la chiave API Anthropic in Impostazioni.
