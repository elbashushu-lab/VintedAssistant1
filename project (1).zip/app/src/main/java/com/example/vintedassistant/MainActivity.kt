package com.example.vintedassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.vintedassistant.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VintedTheme {
                val nav = rememberNavController()
                val vm: MainViewModel = viewModel()
                NavHost(nav, startDestination = "home") {
                    composable("home") {
                        HomeScreen(vm, onPreview = { nav.navigate("preview") },
                            onSaved = { nav.navigate("saved") }, onSettings = { nav.navigate("settings") })
                    }
                    composable("preview") {
                        PreviewScreen(vm, onBack = { nav.popBackStack() }, onTransfer = { nav.navigate("transfer/$it") })
                    }
                    composable("transfer/{i}") { entry ->
                        val i = entry.arguments?.getString("i")?.toIntOrNull() ?: 0
                        TransferScreen(vm, i, onBack = { nav.popBackStack() })
                    }
                    composable("saved") {
                        SavedScreen(vm, onBack = { nav.popBackStack() }, onOpen = { vm.open(it); nav.navigate("preview") })
                    }
                    composable("settings") { SettingsScreen(vm, onBack = { nav.popBackStack() }) }
                }
            }
        }
    }
}
