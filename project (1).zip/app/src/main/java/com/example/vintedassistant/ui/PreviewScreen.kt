package com.example.vintedassistant.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.vintedassistant.MainViewModel
import com.example.vintedassistant.data.CONDITIONS
import java.io.File

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PreviewScreen(vm: MainViewModel, onBack: () -> Unit, onTransfer: (Int) -> Unit) {
    val drafts = vm.drafts
    var tab by rememberSaveable { mutableIntStateOf(vm.startTab) }
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) { vm.message?.let { snack.showSnackbar(it); vm.message = null } }
    if (drafts.isEmpty()) { LaunchedEffect(Unit) { onBack() }; return }
    val i = tab.coerceIn(0, drafts.lastIndex)
    val d = drafts[i]

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Anteprima annunci") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") } },
                actions = { if (drafts.size > 1) TextButton(onClick = { vm.saveAll() }) { Text("Salva tutti") } })
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = { vm.save(i) }, modifier = Modifier.weight(1f)) { Text("Salva scheda") }
                    Button(onClick = { vm.save(i); onTransfer(i) }, modifier = Modifier.weight(1f)) { Text("Vai a Vinted") }
                }
            }
        },
        snackbarHost = { SnackbarHost(snack) },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (drafts.size > 1) TabRow(selectedTabIndex = i) {
                drafts.forEachIndexed { k, dr ->
                    Tab(selected = k == i, onClick = { tab = k },
                        text = { Text(dr.title.take(14).ifBlank { "Articolo ${k + 1}" }) })
                }
            }
            Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(d.photos) { p -> AsyncImage(File(p), null, Modifier.size(110.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop) }
                }
                d.error?.let {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Text("Generazione non riuscita: $it", Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
                if (d.warnings.isNotEmpty()) Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Da verificare", style = MaterialTheme.typography.titleSmall)
                        d.warnings.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                    }
                }
                OutlinedButton(onClick = { vm.regenerate(i) }, enabled = !vm.generating) {
                    Text(if (vm.generating) "Rigenerazione…" else "Rigenera con AI")
                }
                Field("Titolo", d.title, { v -> vm.edit(i) { it.copy(title = v) } }, hint = "${d.title.length} caratteri · da compilare")
                Field("Descrizione", d.description, { v -> vm.edit(i) { it.copy(description = v) } }, minLines = 6)
                Field("Categoria", d.category, { v -> vm.edit(i) { it.copy(category = v) } })
                Field("Marca", d.brand, { v -> vm.edit(i) { it.copy(brand = v) } }, hint = "Non rilevata: inseriscila se la conosci")
                Field("Taglia", d.size, { v -> vm.edit(i) { it.copy(size = v) } }, hint = "Non rilevata: inseriscila se la conosci")
                Text("Condizioni", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CONDITIONS.forEach { c ->
                        FilterChip(selected = d.condition == c, onClick = { vm.edit(i) { it.copy(condition = if (it.condition == c) "" else c) } }, label = { Text(c) })
                    }
                }
                Field("Colore", d.color, { v -> vm.edit(i) { it.copy(color = v) } })
                Field("Materiale", d.material, { v -> vm.edit(i) { it.copy(material = v) } }, hint = "Non rilevato")
                Field("Prezzo (€)", d.price, { v -> vm.edit(i) { it.copy(price = v) } }, keyboard = KeyboardType.Decimal, hint = "Decidi tu")
                Field("Hashtag", d.hashtags, { v -> vm.edit(i) { it.copy(hashtags = v) } })
            }
        }
    }
}
