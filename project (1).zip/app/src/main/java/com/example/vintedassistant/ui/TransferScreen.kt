package com.example.vintedassistant.ui

import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.example.vintedassistant.MainViewModel
import com.example.vintedassistant.data.Draft
import com.example.vintedassistant.data.PhotoStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransferScreen(vm: MainViewModel, index: Int, onBack: () -> Unit) {
    val d: Draft = vm.drafts.getOrNull(index) ?: run { LaunchedEffect(Unit) { onBack() }; return }
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    fun copy(label: String, text: String) {
        clip.setText(AnnotatedString(text)); Toast.makeText(ctx, "$label copiato", Toast.LENGTH_SHORT).show()
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Pubblica su Vinted") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") } })
    }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("La pubblicazione si completa a mano nell'app ufficiale Vinted: questa app non invia nulla per te. Segui i 3 passi.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

            SectionCard {
                Text("1 · Foto", style = MaterialTheme.typography.titleMedium)
                Text("Salva le ${d.photos.size} foto nella Galleria (cartella Pictures/VintedAssistant), poi sceglile in Vinted.")
                FilledTonalButton(onClick = {
                    scope.launch {
                        val n = withContext(Dispatchers.IO) { PhotoStore.saveToGallery(ctx, d.photos) }
                        Toast.makeText(ctx, "$n foto salvate in Galleria", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Salva foto in Galleria") }
            }

            SectionCard {
                Text("2 · Apri Vinted", style = MaterialTheme.typography.titleMedium)
                Text("Tocca “Vendi un articolo”, scegli le foto e poi copia i campi qui sotto.")
                FilledTonalButton(onClick = {
                    val intent = ctx.packageManager.getLaunchIntentForPackage("fr.vinted")
                        ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.vinted.it/items/new"))
                    ctx.startActivity(intent)
                }) { Text("Apri app Vinted") }
            }

            SectionCard {
                Text("3 · Copia i campi", style = MaterialTheme.typography.titleMedium)
                CopyRow("Titolo", d.title) { copy("Titolo", it) }
                CopyRow("Descrizione", listOf(d.description, d.hashtags).filter { it.isNotBlank() }.joinToString("\n\n")) { copy("Descrizione", it) }
                CopyRow("Categoria", d.category) { copy("Categoria", it) }
                CopyRow("Marca", d.brand) { copy("Marca", it) }
                CopyRow("Taglia", d.size) { copy("Taglia", it) }
                CopyRow("Condizioni", d.condition) { copy("Condizioni", it) }
                CopyRow("Colore", d.color) { copy("Colore", it) }
                CopyRow("Materiale", d.material) { copy("Materiale", it) }
                CopyRow("Prezzo", d.price) { copy("Prezzo", it) }
            }
        }
    }
}

@Composable
private fun CopyRow(label: String, value: String, onCopy: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            Text(value.ifBlank { "—" }, maxLines = 3, style = MaterialTheme.typography.bodyMedium)
        }
        TextButton(onClick = { onCopy(value) }, enabled = value.isNotBlank()) { Text("Copia") }
    }
}
