package com.example.vintedassistant.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** Scheda articolo in memoria (modificabile nell'anteprima). */
data class Draft(
    val savedId: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val photos: List<String> = emptyList(),
    val title: String = "",
    val description: String = "",
    val category: String = "",
    val brand: String = "",
    val size: String = "",
    val condition: String = "",
    val color: String = "",
    val material: String = "",
    val price: String = "",
    val hashtags: String = "",
    val warnings: List<String> = emptyList(),
    val error: String? = null,
) {
    fun fullText() = buildString {
        appendLine(title); appendLine(); append(description)
        if (hashtags.isNotBlank()) { appendLine(); appendLine(); append(hashtags) }
    }
}

@Entity(tableName = "items")
data class ItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAt: Long,
    val title: String, val description: String, val category: String,
    val brand: String, val size: String, val condition: String,
    val color: String, val material: String, val price: String,
    val hashtags: String, val warnings: String, val photos: String,
)

fun Draft.toEntity() = ItemEntity(
    id = savedId ?: 0, createdAt = createdAt, title = title, description = description,
    category = category, brand = brand, size = size, condition = condition, color = color,
    material = material, price = price, hashtags = hashtags,
    warnings = warnings.joinToString("\n"), photos = photos.joinToString("|"),
)

fun ItemEntity.toDraft() = Draft(
    savedId = id, createdAt = createdAt, photos = photos.split("|").filter { it.isNotBlank() },
    title = title, description = description, category = category, brand = brand, size = size,
    condition = condition, color = color, material = material, price = price, hashtags = hashtags,
    warnings = warnings.split("\n").filter { it.isNotBlank() },
)

@Dao
interface ItemDao {
    @Query("SELECT * FROM items ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<ItemEntity>>
    @Insert suspend fun insert(item: ItemEntity): Long
    @Update suspend fun update(item: ItemEntity)
    @Query("DELETE FROM items WHERE id = :id") suspend fun delete(id: Long)
}

@Database(entities = [ItemEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun itemDao(): ItemDao
    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(c: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDatabase::class.java, "vinted.db")
                .build().also { inst = it }
        }
    }
}

class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private fun get(k: String, d: String = "") = p.getString(k, d) ?: d
    private fun put(k: String, v: String) = p.edit().putString(k, v.trim()).apply()

    var provider: String
        get() = get("provider", "gemini")
        set(v) = put("provider", v)
    var geminiKey: String
        get() = get("gemini_key")
        set(v) = put("gemini_key", v)
    var geminiModel: String
        get() = get("gemini_model", GEMINI_MODEL)
        set(v) = put("gemini_model", v.ifBlank { GEMINI_MODEL })
    var claudeKey: String
        get() = get("claude_key")
        set(v) = put("claude_key", v)
    var claudeModel: String
        get() = get("claude_model", CLAUDE_MODEL)
        set(v) = put("claude_model", v.ifBlank { CLAUDE_MODEL })

    val apiKey: String get() = if (provider == "gemini") geminiKey else claudeKey
    val model: String get() = if (provider == "gemini") geminiModel else claudeModel

    companion object {
        const val GEMINI_MODEL = "gemini-flash-latest"
        const val CLAUDE_MODEL = "claude-sonnet-5-5"
    }
}
