package com.example.vintedassistant.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.vintedassistant.MainViewModel
import com.example.vintedassistant.data.MAX_PHOTOS

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: MainViewModel, onPreview: () -> Unit, onSaved: () -> Unit, onSettings: () -> Unit) {
    var target by remember { mutableIntStateOf(0) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(MAX_PHOTOS)) { uris ->
        if (uris.isNotEmpty()) vm.setPhotos(target, uris)
    }
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) { vm.message?.let { snack.showSnackbar(it); vm.message = null } }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Vinted Assistant") }, actions = {
                IconButton(onClick = onSaved) { Icon(Icons.AutoMirrored.Filled.List, "Schede salvate") }
                IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Impostazioni") }
            })
        },
        snackbarHost = { SnackbarHost(snack) },
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Text("Scegli le foto di 3 articoli (fino a $MAX_PHOTOS foto ciascuno), scrivi l'istruzione unica e lascia fare all'AI.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            itemsIndexed(vm.picked) { i, uris ->
                SectionCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Articolo ${i + 1}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        FilledTonalButton(onClick = {
                            target = i
                            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }) { Text(if (uris.isEmpty()) "Scegli foto" else "Cambia foto") }
                    }
                    if (uris.isEmpty()) Text("Nessuna foto selezionata", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(uris) { u ->
                            AsyncImage(u, null, Modifier.size(88.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
                        }
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = vm.instruction, onValueChange = { vm.instruction = it },
                    label = { Text("Istruzione unica") },
                    placeholder = { Text("Es. Tono amichevole, spedizione in 48h, sconto del 10% se prendi 2 articoli, vengo da casa senza fumatori…") },
                    modifier = Modifier.fillMaxWidth(), minLines = 4,
                )
            }
            item {
                Button(
                    onClick = { vm.generate(onPreview) },
                    enabled = !vm.generating && vm.picked.all { it.isNotEmpty() },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) {
                    if (vm.generating) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                        Spacer(Modifier.width(12.dp)); Text("Analisi in corso…")
                    } else Text("Genera i 3 annunci")
                }
                if (vm.drafts.isNotEmpty() && !vm.generating) TextButton(onClick = onPreview, modifier = Modifier.fillMaxWidth()) { Text("Torna all'anteprima") }
            }
        }
    }
}
