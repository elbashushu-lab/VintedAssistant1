package com.example.vintedassistant.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.provider.MediaStore
import java.io.File
import java.util.UUID
import kotlin.math.max
import kotlin.math.roundToInt

const val MAX_PHOTOS = 5
val CONDITIONS = listOf("Nuovo con cartellino", "Nuovo senza cartellino", "Ottime condizioni", "Buone condizioni", "Condizioni soddisfacenti")

object PhotoStore {
    /** Copia la foto nello storage privato dell'app, ridimensionata (max 1280px) e in JPEG. */
    fun import(ctx: Context, uri: Uri): File {
        val src = ImageDecoder.createSource(ctx.contentResolver, uri)
        val bmp = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            val m = max(info.size.width, info.size.height)
            if (m > 1280) {
                val s = 1280f / m
                dec.setTargetSize((info.size.width * s).roundToInt(), (info.size.height * s).roundToInt())
            }
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
        val dir = File(ctx.filesDir, "photos").apply { mkdirs() }
        val f = File(dir, "${UUID.randomUUID()}.jpg")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        bmp.recycle()
        return f
    }

    /** Esporta le foto in Galleria (Pictures/VintedAssistant) così l'app Vinted può selezionarle. */
    fun saveToGallery(ctx: Context, paths: List<String>): Int {
        var n = 0
        for (p in paths) {
            val f = File(p)
            val v = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, f.name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/VintedAssistant")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: continue
            ctx.contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
            v.clear(); v.put(MediaStore.Images.Media.IS_PENDING, 0)
            ctx.contentResolver.update(uri, v, null, null)
            n++
        }
        return n
    }
}
